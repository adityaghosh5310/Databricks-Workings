-- Databricks notebook source
-- DBTITLE 1,Inserting UnStruc Data
create or replace temp view raw_unstructured_docall as
select 
path,
content
from read_files('/Volumes/projects_data_youtube/default/final_project')

-- COMMAND ----------

-- DBTITLE 1,Parsing the Unstruc Data
create or replace temp view parsed_structured_docall as 
select path,
ai_parse_document(content) as parsedcontent from raw_unstructured_docall

-- COMMAND ----------

-- DBTITLE 1,Cleaning and classify the Unstruc Data
create or replace temp view parsed_clean_cato_all_data as
select path,
concat_ws('\n',
transform(try_cast(parsedcontent:document:elements as array<VARIANT>), e -> coalesce(try_cast(e:content as string), ''))
) as docu_text,
ai_classify(to_json(parsedcontent), array('Invoice','Receipt','PurchaseOrder')) as doc_text
from parsed_structured_docall

-- COMMAND ----------

-- DBTITLE 1,Extracting the required Invoice Data in array
create or replace temp view parsed_clean_invoice_data as 
select path,
  ai_extract(docu_text,
    array('Vendor_Name','InvoiceNumber','InvoiceDate','DueDate','PaymentMethod','TotalAmount','Currency')
  ) as Extracted
from
  parsed_clean_cato_all_data
where
  doc_text = 'Invoice'

-- COMMAND ----------

-- DBTITLE 1,Invoice Final Data
create or replace table idp.default.parsed_clean_invoices as 
select 
  path,
  Extracted.Vendor_Name as VendorName,
  Extracted.InvoiceNumber as InvoiceNumber,
  date_format(to_date(Extracted.InvoiceDate, 'yyyy-MM-dd'), 'MM/dd/yyyy') as InvoiceDate,
  date_format(to_date(Extracted.DueDate, 'yyyy-MM-dd'), 'MM/dd/yyyy') as DueDate,
  Extracted.PaymentMethod as PaymentMethod,
  cast(Extracted.TotalAmount as decimal(10,2)) as TotalAmount,
  Extracted.Currency as Currency
from parsed_clean_invoice_data

-- COMMAND ----------

-- DBTITLE 1,Extracting the required Receipt Data in array
create or replace temp view parsed_clean_receipt_data as
select 
  path,
  ai_extract(
    docu_text,
    array('Vendor_Name','Address','ReceiptNumber','DateTime','TotalAmount','Currency','PaymentMethod')
  ) as Extracted
from
  parsed_clean_cato_all_data 
where doc_text = 'Receipt'

-- COMMAND ----------

-- DBTITLE 1,Receipt Final Data
create or replace table idp.default.parsed_clean_receipts as 
select 
  path,
  Extracted.Vendor_Name as VendorName,
  Extracted.Address as Address,
  Extracted.ReceiptNumber as ReceiptNumber,
  cast(Extracted.DateTime as timestamp) as ReceiptDateTime,
  cast(Extracted.TotalAmount as decimal(10,2)) as TotalAmount,
  Extracted.Currency as Currency,
  Extracted.PaymentMethod as PaymentMethod
from parsed_clean_receipt_data

-- COMMAND ----------

-- DBTITLE 1,Extracting the required puchase order Data in array
create or replace temp view parsed_clean_purchaseorder_data as
select 
  path,
  ai_extract(
    docu_text,
    array('BuyerName','PO_Number','VendorName','RequestShipDate','TotalAmount','Currency')
  ) as Extracted
from
  parsed_clean_cato_all_data
where doc_text = 'PurchaseOrder'

-- COMMAND ----------

-- DBTITLE 1,Purchase Order Final Data
create or replace table idp.default.parsed_clean_purchaseorders as 
select 
  path,
  Extracted.PO_Number as PONumber,
  Extracted.BuyerName as BuyerName,
  Extracted.VendorName as VendorName,
  date_format(to_date(Extracted.RequestShipDate, 'yyyy-MM-dd'), 'MM/dd/yyyy') as RequestShipDate,
  cast(Extracted.TotalAmount as decimal(10,2)) as TotalAmount,
  Extracted.Currency as Currency
from parsed_clean_purchaseorder_data

-- COMMAND ----------

select * from idp.default.parsed_clean_invoices;
select * from idp.default.parsed_clean_purchaseorders;
select * from idp.default.parsed_clean_receipts;