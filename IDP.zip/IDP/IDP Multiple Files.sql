-- Databricks notebook source
create or replace temp view raw_unstructured_docall as
select 
path,
content
from read_files('/Volumes/projects_data_youtube/default/workingdata/DatabricksIDP-main/classify/')

-- COMMAND ----------

create or replace temp view parsed_structured_docall as 
select path,
ai_parse_document(content) as parsedcontent from raw_unstructured_docall

-- COMMAND ----------

select path,parsedcontent from parsed_structured_docall

-- COMMAND ----------

select *,
ai_classify(to_json(parsedcontent), array('Claim','LabReports','Notes','AdminDoc','MediInvoice')) as document_type
from parsed_structured_docall

-- COMMAND ----------

