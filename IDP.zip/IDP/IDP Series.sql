-- Databricks notebook source
create or replace temp view raw_unstructured_doc as
select 
path,
content
from read_files('/Volumes/projects_data_youtube/default/workingdata/DatabricksIDP-main/sample_medical_claim.pdf')

-- COMMAND ----------

select path,length(content) from raw_unstructured_doc

-- COMMAND ----------

create or replace temp view parsed_structured_doc as 
select path,
ai_parse_document(content) as parsedcontent from raw_unstructured_doc

-- COMMAND ----------

select * from parsed_structured_doc

-- COMMAND ----------

create or replace temp view structured_table as
select 
  path,
  try_cast(e:content as string) as table_html
from parsed_structured_doc
lateral view explode(
  try_cast(parsedcontent:document:elements as array<VARIANT>)
) t as e
where try_cast(e:type as string) = 'table'

-- COMMAND ----------

select * from structured_table

-- COMMAND ----------

select 
ai_extract(table_html, array('CPT Code')),
ai_extract(table_html, array('ICD Code')),
ai_extract(table_html, array('Description')),
ai_extract(table_html, array('Paid Amount'))
from structured_table

-- COMMAND ----------

select 
  ai_extract(table_html, array('CPT Code')).`CPT Code` as cpt_code,
  ai_extract(table_html, array('ICD Code')).`ICD Code` as icd_code,
  ai_extract(table_html, array('Description')).`Description` as description,
  ai_extract(table_html, array('Billed Amount')).`Billed Amount` as Billed_Amount,
  ai_extract(table_html, array('Paid Amount')).`Paid Amount` as paid_amount
from structured_table

-- COMMAND ----------

-- DBTITLE 1,Flatten data into rows
with extracted as (
  select 
    from_json(cpt_code, 'array<string>') as cpt_array,
    from_json(icd_code, 'array<string>') as icd_array,
    from_json(description, 'array<string>') as desc_array,
    from_json(Billed_Amount, 'array<string>') as billed_array,
    from_json(paid_amount, 'array<string>') as paid_array
  from _sqldf
)
select 
  cast(cpt as int) as CPTCode,
  icd as ICDCode,
  desc as Description,
  cast(regexp_replace(billed, '\\$|,', '') as decimal(10,2)) as BilledAmount,
  cast(regexp_replace(paid, '\\$|,', '') as decimal(10,2)) as PaidAmount
from extracted
lateral view posexplode(cpt_array) cpt_t as cpt_pos, cpt
lateral view posexplode(icd_array) icd_t as icd_pos, icd
lateral view posexplode(desc_array) desc_t as desc_pos, desc
lateral view posexplode(billed_array) billed_t as billed_pos, billed
lateral view posexplode(paid_array) paid_t as paid_pos, paid
where cpt_pos = icd_pos 
  and cpt_pos = desc_pos 
  and cpt_pos = billed_pos
  and cpt_pos = paid_pos