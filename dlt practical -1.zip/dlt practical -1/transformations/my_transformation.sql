--Streaming Table
CREATE STREAMING TABLE bronze_raw_orders
COMMENT "this is order raw data"
AS SELECT * FROM cloud_files("/Volumes/dlt/default/dlt_files/orders/", "json",
map(
    'cloudFiles.inferColumnTypes', 'true',
    'cloudFiles.includeExistingFiles', 'true',
    'cloudFiles.schemaEvolutionMode', 'addNewColumns'
));

--Materialized view table
create materialized view silver_orders 
comment "it is a curated order details"
as
select 
order_id, customer_id, country, cast(order_ts as timestamp) as order_ts,
cast(amount as double) as amount, status
from bronze_raw_orders where status = 'Completed';


--View
CREATE VIEW in_order
COMMENT "Final Populated Data"
as
select 
* from silver_orders where country = 'IN';