import dlt
from pyspark.sql.functions import *
from pyspark.sql.types import *

@dlt.table(
    name = 'bronze_orders'
)
def bronze_orders():
  return (
    spark.readStream.format("cloudFiles")
      .option("cloudFiles.format", "json")
      .option("cloudFiles.inferColumnTypes", "true")
      .option("cloudFiles.schemaevolutionMode", "addNewColumns")
      .option("cloudFiles.includeExistingFiles", "true")
      .load("/Volumes/dlt/default/dlt_files")
  )

@dlt.table(
    name = 'silver_orders_py'
)
@dlt.expect_or_drop("non_negative_amount", "cast(amount as double) >= 0")
def silver_orders():
    return (
      dlt.read_stream("bronze_orders")
      .withColumn("order_ts", col("order_ts").cast(TimestampType()))
      .withColumn("amount", col("amount").cast(DoubleType()))
      .filter(col("status") == lit("Completed"))
      .select(
          col("order_id"), col("customer_id"), col("country"), col("order_ts"), col("amount"), col("status"))
      .dropDuplicates(["order_id"])
    )

@dlt.view(
    name = 'in_order'
)
def is_order():
    return (
      dlt.read("silver_orders_py")
      .filter(col("country") == lit("US")))