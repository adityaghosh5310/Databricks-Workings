-- Databricks notebook source
drop table dlt.default.bronze_orders

-- COMMAND ----------

select * from dlt.default.bronze_orders

-- COMMAND ----------

select * from dlt.default.silver_orders_py